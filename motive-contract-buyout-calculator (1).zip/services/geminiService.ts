import { GoogleGenAI, Type } from "@google/genai";
import { PRODUCT_LIST } from "../constants";
import mammoth from "mammoth";
import * as XLSX from "xlsx";

// Helper to convert file to base64 (for PDF/Images)
const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = error => reject(error);
  });
};

// Helper to extract text from DOCX
const extractDocxText = async (file: File): Promise<string> => {
  const arrayBuffer = await file.arrayBuffer();
  const result = await mammoth.extractRawText({ arrayBuffer });
  return result.value;
};

// Helper to extract text from Excel
const extractExcelText = async (file: File): Promise<string> => {
  const arrayBuffer = await file.arrayBuffer();
  const workbook = XLSX.read(arrayBuffer, { type: 'array' });
  
  let combinedText = "";
  workbook.SheetNames.forEach(sheetName => {
    const worksheet = workbook.Sheets[sheetName];
    // Convert sheet to CSV format which is token-efficient and easy for AI to parse
    const csv = XLSX.utils.sheet_to_csv(worksheet);
    combinedText += `\n--- Sheet: ${sheetName} ---\n${csv}`;
  });
  
  return combinedText;
};

export const parseContractWithGemini = async (file: File): Promise<any> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key is missing.");
  }

  const ai = new GoogleGenAI({ apiKey });
  
  const systemPrompt = `
    You are an expert contract analyst for Motive.
    Analyze the provided contract data. Extract the following information:
    1. Contract Name or ID.
    2. Start Date (YYYY-MM-DD).
    3. End Date (YYYY-MM-DD).
    4. Line Items: Extract ALL products/services listed in the contract.
       - If a product matches one of the following known products, use the exact name from this list:
       ${JSON.stringify(PRODUCT_LIST)}
       - If it is a different product (competitor device, unknown service, custom item, etc.), EXTRACT IT EXACTLY AS WRITTEN in the document. Do not omit it.
       - Extract Quantity and Monthly Unit Price for each.
    
    Return strict JSON.
  `;

  const schema = {
    type: Type.OBJECT,
    properties: {
      name: { type: Type.STRING, description: "Contract ID or Customer Name" },
      startDate: { type: Type.STRING, description: "YYYY-MM-DD" },
      endDate: { type: Type.STRING, description: "YYYY-MM-DD" },
      lineItems: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            productName: { type: Type.STRING },
            quantity: { type: Type.NUMBER },
            unitPrice: { type: Type.NUMBER }
          }
        }
      }
    }
  };

  try {
    let contentParts: any[] = [];

    // Strategy 1: PDF or Image (Native Multimodal)
    if (file.type === 'application/pdf' || file.type.startsWith('image/')) {
       const base64Data = await fileToBase64(file);
       contentParts = [
         { text: systemPrompt },
         {
           inlineData: {
             mimeType: file.type,
             data: base64Data
           }
         }
       ];
    } 
    // Strategy 2: DOCX (Extract Text)
    else if (
        file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' || 
        file.name.endsWith('.docx')
    ) {
        const text = await extractDocxText(file);
        contentParts = [
            { text: systemPrompt },
            { text: `Here is the text content of the DOCX contract:\n\n${text}` }
        ];
    }
    // Strategy 3: Excel (Extract CSV)
    else if (
        file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || 
        file.type === 'application/vnd.ms-excel' ||
        file.name.endsWith('.xlsx') ||
        file.name.endsWith('.xls')
    ) {
        const text = await extractExcelText(file);
        contentParts = [
            { text: systemPrompt },
            { text: `Here is the data content of the Excel contract:\n\n${text}` }
        ];
    }
    else {
        // Fallback for text files or other formats
        throw new Error(`Unsupported file type: ${file.type}. Please use PDF, Docx, Excel, or Image.`);
    }

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        {
          role: 'user',
          parts: contentParts
        }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: schema
      }
    });

    const text = response.text;
    if (!text) return null;
    return JSON.parse(text);

  } catch (error) {
    console.error("Error parsing contract with Gemini:", error);
    throw error;
  }
};