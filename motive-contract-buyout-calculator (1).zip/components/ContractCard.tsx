import React from 'react';
import { Contract, LineItem } from '../types';
import { calculateContractMetrics, formatCurrency } from '../utils';
import { PRODUCT_LIST } from '../constants';
import { Trash2, Plus, AlertCircle } from 'lucide-react';

interface ContractCardProps {
  contract: Contract;
  index: number;
  onUpdate: (updated: Contract) => void;
  onDelete: () => void;
}

const ContractCard: React.FC<ContractCardProps> = ({ contract, index, onUpdate, onDelete }) => {
  const metrics = calculateContractMetrics(contract);

  const handleLineItemChange = (lIndex: number, field: keyof LineItem, value: any) => {
    const newItems = [...contract.lineItems];
    newItems[lIndex] = { ...newItems[lIndex], [field]: value };
    onUpdate({ ...contract, lineItems: newItems });
  };

  const addLineItem = () => {
    const newItem: LineItem = {
      id: Math.random().toString(36).substr(2, 9),
      productName: "",
      quantity: 1,
      unitPrice: 0
    };
    onUpdate({ ...contract, lineItems: [...contract.lineItems, newItem] });
  };

  const removeLineItem = (lIndex: number) => {
    const newItems = contract.lineItems.filter((_, i) => i !== lIndex);
    onUpdate({ ...contract, lineItems: newItems });
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-visible mb-6 transition-all hover:shadow-md">
      <div className="bg-gray-50 px-6 py-4 border-b border-gray-200 flex justify-between items-center flex-wrap gap-4 rounded-t-xl">
        <div className="flex items-center gap-3">
            <span className="bg-motive-600 text-white text-xs font-bold px-2 py-1 rounded">
                #{index + 1}
            </span>
            <input 
                type="text" 
                value={contract.name}
                onChange={(e) => onUpdate({...contract, name: e.target.value})}
                placeholder="Contract Name / ID"
                className="font-semibold text-gray-800 bg-transparent border-b border-transparent hover:border-gray-300 focus:border-motive-500 focus:outline-none px-1"
            />
        </div>
        <button 
            onClick={onDelete}
            className="text-red-500 hover:text-red-700 hover:bg-red-50 p-2 rounded-full transition-colors"
            title="Remove Contract"
        >
            <Trash2 size={18} />
        </button>
      </div>

      <div className="p-6">
        {/* Dates Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="space-y-4">
                <div>
                    <label className="block text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">Start Date</label>
                    <input 
                        type="date" 
                        value={contract.startDate}
                        onChange={(e) => onUpdate({...contract, startDate: e.target.value})}
                        className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-motive-500 focus:border-motive-500 outline-none text-gray-900 bg-white"
                    />
                </div>
                <div>
                    <label className="block text-xs font-medium text-gray-500 uppercase tracking-wider mb-1">End Date</label>
                    <input 
                        type="date" 
                        value={contract.endDate}
                        onChange={(e) => onUpdate({...contract, endDate: e.target.value})}
                        className="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-motive-500 focus:border-motive-500 outline-none text-gray-900 bg-white"
                    />
                </div>
            </div>

            {/* Metrics Display */}
            <div className="bg-motive-50 rounded-lg p-4 flex flex-col justify-center space-y-3">
                <div className="flex justify-between items-center">
                    <span className="text-gray-600 text-sm">Total Length:</span>
                    <span className="font-semibold text-gray-900">{metrics.totalContractLengthMonths} Months</span>
                </div>
                <div className="flex justify-between items-center border-t border-motive-200 pt-3">
                    <span className="text-gray-600 text-sm">Remaining:</span>
                    <span className="font-bold text-motive-700 text-lg">{metrics.remainingMonths} Months</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-gray-500 mt-2">
                    <AlertCircle size={12} />
                    <span>Calculated from today to end date</span>
                </div>
            </div>
        </div>

        {/* Line Items Section */}
        <div className="mb-4">
            <div className="flex justify-between items-center mb-3">
                <h4 className="text-sm font-bold text-gray-800 uppercase tracking-wide">Line Items</h4>
                <div className="text-right text-sm text-gray-500">
                    Monthly Total: <span className="font-semibold text-gray-900">{formatCurrency(metrics.monthlyTotal)}</span>
                </div>
            </div>

            <div className="space-y-3">
                {contract.lineItems.map((item, i) => (
                    <div key={item.id} className="grid grid-cols-12 gap-3 items-end bg-white p-3 border border-gray-100 rounded-lg hover:border-gray-300 transition-colors">
                        <div className="col-span-12 md:col-span-5">
                            <label className="block text-xs text-gray-500 mb-1 md:hidden">Product</label>
                            <div className="relative">
                                <input 
                                    type="text"
                                    list={`product-list-${contract.id}-${item.id}`}
                                    value={item.productName}
                                    onChange={(e) => handleLineItemChange(i, 'productName', e.target.value)}
                                    placeholder="Enter or select product..."
                                    className="w-full border border-gray-300 rounded-md p-2 text-sm focus:ring-1 focus:ring-motive-500 outline-none text-gray-900 bg-white"
                                />
                                <datalist id={`product-list-${contract.id}-${item.id}`}>
                                    {PRODUCT_LIST.map(p => (
                                        <option key={p} value={p} />
                                    ))}
                                </datalist>
                            </div>
                        </div>
                        <div className="col-span-4 md:col-span-2">
                             <label className="block text-xs text-gray-500 mb-1">Qty</label>
                            <input 
                                type="number" 
                                min="1"
                                value={item.quantity}
                                onChange={(e) => handleLineItemChange(i, 'quantity', parseInt(e.target.value) || 0)}
                                className="w-full border border-gray-300 rounded-md p-2 text-sm focus:ring-1 focus:ring-motive-500 outline-none text-gray-900 bg-white"
                            />
                        </div>
                        <div className="col-span-6 md:col-span-3">
                             <label className="block text-xs text-gray-500 mb-1">Unit Price ($/mo)</label>
                            <input 
                                type="number" 
                                min="0"
                                step="0.01"
                                value={item.unitPrice}
                                onChange={(e) => handleLineItemChange(i, 'unitPrice', parseFloat(e.target.value) || 0)}
                                className="w-full border border-gray-300 rounded-md p-2 text-sm focus:ring-1 focus:ring-motive-500 outline-none text-gray-900 bg-white"
                            />
                        </div>
                        <div className="col-span-2 md:col-span-2 flex justify-end pb-1">
                             <button 
                                onClick={() => removeLineItem(i)}
                                className="text-gray-400 hover:text-red-500 p-1"
                             >
                                 <Trash2 size={16} />
                             </button>
                        </div>
                    </div>
                ))}
            </div>

            <button 
                onClick={addLineItem}
                className="mt-3 flex items-center gap-2 text-sm font-medium text-motive-600 hover:text-motive-700"
            >
                <Plus size={16} /> Add Product
            </button>
        </div>

        {/* Contract Total */}
        <div className="mt-6 border-t border-gray-200 flex justify-between items-center bg-gray-900 -mx-6 -mb-6 px-6 py-4 rounded-b-xl">
            <span className="text-gray-300 font-medium">Contract Buyout Total</span>
            <span className="text-xl font-bold text-white">{formatCurrency(metrics.totalBuyout)}</span>
        </div>
      </div>
    </div>
  );
};

export default ContractCard;